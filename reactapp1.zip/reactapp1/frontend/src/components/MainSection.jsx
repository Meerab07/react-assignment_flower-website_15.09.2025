import React from 'react';
import './MainSection.css';

const MainSection = () => {
  const flowers = [
    {
      name: "Roses",
      image: "https://th.bing.com/th/id/R.9ebad7ea4dd2c2b3b9e986d810dd2fc4?rik=Nz1%2b5fV0aqrTww&pid=ImgRaw&r=0",
      season: "Spring to Fall",
      location: "Outdoors, Full Sun",
      care: "Water regularly, well-drained soil, prune in late winter"
    },
    {
      name: "Sunflowers",
      image: "https://images.pexels.com/photos/54267/sunflower-blossom-bloom-flowers-54267.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260",
      season: "Summer to Early Fall",
      location: "Outdoors, Full Sun",
      care: "Deep watering, tall support stakes, rich soil"
    },
    {
      name: "Tulips",
      image: "https://th.bing.com/th/id/R.6922c36436fc713c8e658c02e839b95d?rik=6JD1k3RqHfjH4w&pid=ImgRaw&r=0",
      season: "Spring",
      location: "Outdoors, Partial Sun",
      care: "Plant bulbs in fall, cool climate, well-drained soil"
    },
    {
      name: "Lavender",
      image: "https://th.bing.com/th/id/R.5339c7a49aeaa7f8fb46c7100c1e1a6a?rik=Y%2bEa%2fnxkGOWgXg&pid=ImgRaw&r=0",
      season: "Summer",
      location: "Outdoors, Full Sun",
      care: "Drought tolerant, sandy soil, minimal watering"
    },
    {
      name: "Orchids",
      image: "https://wallup.net/wp-content/uploads/2019/09/849097-orchid-orchids-exotic-close-up.jpg",
      season: "Year-round (Indoor)",
      location: "Indoors, Bright Indirect Light",
      care: "Weekly watering, high humidity, bark-based soil"
    },
    {
      name: "Daffodils",
      image: "https://images6.alphacoders.com/725/725146.jpg",
      season: "Early Spring",
      location: "Outdoors, Sun to Partial Shade",
      care: "Plant bulbs in fall, naturalize easily, low maintenance"
    },
    {
      name: "Peonies",
      image: "https://th.bing.com/th/id/R.adc74b5083e373eea145c41b91fa1034?rik=0krbhm8RIvQDMg&pid=ImgRaw&r=0",
      season: "Late Spring to Early Summer",
      location: "Outdoors, Morning Sun",
      care: "Rich soil, support for heavy blooms, avoid moving"
    },
    {
      name: "Marigolds",
      image: "https://www.gardeningknowhow.com/wp-content/uploads/2020/11/orange-french-marigolds.jpg",
      season: "Spring to First Frost",
      location: "Outdoors, Full Sun",
      care: "Easy care, deadhead regularly, drought tolerant"
    },
    {
      name: "Violets",
      image: "https://cdn2.hubspot.net/hubfs/456762/closeupwv.jpg#keepProtocol",
      season: "Spring and Fall",
      location: "Indoors or Outdoors, Partial Shade",
      care: "Moist soil, cool temperatures, gentle care"
    },
    {
      name: "Hydrangeas",
      image: "https://tse1.mm.bing.net/th/id/OIP.VmygLVL3adeJNoktgr1QagHaE7?rs=1&pid=ImgDetMain&o=7&rm=3",
      season: "Summer to Fall",
      location: "Outdoors, Morning Sun/Afternoon Shade",
      care: "Consistent moisture, acidic soil, winter protection"
    }
  ];

  return (
    <main className="main-section">
      <div className="main-container">
        <section className="hero-section">
          <h1>🌺 Welcome to Bloom Guide</h1>
          <p>Your comprehensive guide to growing beautiful flowers throughout the seasons. Discover care tips, blooming periods, and the perfect spots for your favorite blooms!</p>
        </section>

        <section className="flowers-section">
          <h2 className="section-title">🌷 Featured Flowers</h2>
          <div className="flowers-grid">
            {flowers.map((flower, index) => (
              <div key={index} className="flower-card">
                <img 
                  src={flower.image} 
                  alt={flower.name} 
                  className="flower-image"
                />
                <div className="flower-content">
                  <h3>{flower.name}</h3>
                  <div className="flower-details">
                    <div className="detail-item">
                      <span className="detail-icon">🌸</span>
                      <span className="detail-label">Blooms:</span>
                      <span className="detail-value">{flower.season}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-icon">📍</span>
                      <span className="detail-label">Location:</span>
                      <span className="detail-value">{flower.location}</span>
                    </div>
                    <div className="detail-item">
                      <span className="detail-icon">💧</span>
                      <span className="detail-label">Care:</span>
                      <span className="detail-value">{flower.care}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="seasonal-guide">
          <h2 className="section-title">🍃 Seasonal Gardening Tips</h2>
          <div className="seasonal-grid">
            <div className="season-card spring">
              <h3>🌱 Spring</h3>
              <p>Plant new bulbs, start seeds indoors, and prepare garden beds. Perfect time for roses, tulips, and daffodils!</p>
            </div>
            <div className="season-card summer">
              <h3>☀️ Summer</h3>
              <p>Focus on watering and deadheading. Sunflowers, marigolds, and lavender thrive in the summer heat.</p>
            </div>
            <div className="season-card fall">
              <h3>🍂 Fall</h3>
              <p>Plant spring bulbs, divide perennials, and enjoy late bloomers like some roses and hydrangeas.</p>
            </div>
            <div className="season-card winter">
              <h3>❄️ Winter</h3>
              <p>Care for indoor plants like orchids, plan next year's garden, and protect outdoor plants from frost.</p>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
};

export default MainSection;